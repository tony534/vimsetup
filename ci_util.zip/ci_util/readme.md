### Util tool for SF CI 

- componentlist: the xml file to list all the salesforce component, including name, file extension and wildcard or not.

- inputFileList: All the modified files without wildcard *.

- outputFileList: All the modified files with wildcard * 

- packageXML: the package.xml generated dynamically.
