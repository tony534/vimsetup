package com.systempartners.ci.flow;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class FlowUtil2 extends Task{

	private File targetSrc;
	private File sourceSrc;
	
	private Map<String, Set<String>> targetFlowMap = new HashMap<String, Set<String>>();
	private Map<String, Set<String>> sourceFlowMap = new HashMap<String, Set<String>>();
	
	private Set<String> sourceFlowSet = new HashSet<String>();
	private Set<String> targetFlowSet = new HashSet<String>();
	
	@Override
	public void execute() throws BuildException {
		super.execute();
		try {
			setFlows(sourceSrc.toPath().resolve("flows").toFile(), this.sourceFlowSet, this.sourceFlowMap); // source flows setup
			setFlows(targetSrc.toPath().resolve("flows").toFile(), this.targetFlowSet, this.targetFlowMap); // target flows setup
			System.out.println("before sourceFlowSet = "+sourceFlowSet);
			this.sourceFlowSet.retainAll(this.targetFlowSet);
			System.out.println("after sourceFlowSet = "+sourceFlowSet);
			int i = 0;
			Path sourcePath = this.sourceSrc.toPath().resolve("flows");
			for(String filename : this.sourceFlowSet) {
				i ++ ;
				getProject().log(i + ": " + filename +" is deleted");
				Path fileTobeDeleted = sourcePath.resolve(filename);
				Files.delete(fileTobeDeleted);
			}
			
			System.out.println(i + " flows were deleted due to active in target org");
			
			
			Map<String,String> activeMap = getActiveMap(sourceSrc.toPath().resolve("flowDefinitions").toFile());
			for(String fd : activeMap.keySet()){ // fd: flow definition name
				String activeNum = activeMap.get(fd);
				Set<String> deletedFlowVersion = this.sourceFlowMap.get(fd);
				
				if(deletedFlowVersion != null && deletedFlowVersion.contains(activeNum)) {
					Files.deleteIfExists((sourceSrc.toPath().resolve("flowDefinitions").resolve(fd)));
				}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/***
	 * get active flow map
	 * 
	 * @param flowDefinitionFolder
	 * @return <active flow name, active flow version number>
	 * @throws Exception
	 */
	
	public Map<String, String> getActiveMap(File flowDefinitionFolder) throws Exception{
		Map<String, String> activeMap = new HashMap<String, String>();
		
		for(File file : flowDefinitionFolder.listFiles()) {
			if(file.getName().endsWith(".flowDefinition")) {
				Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
				NodeList nl = doc.getElementsByTagName("activeVersionNumber");
				
				if(nl != null && nl.getLength() != 0 ) { // active
					String activeVersion = nl.item(0).getFirstChild().getNodeValue();
					String flowFileName = file.getName().replace(".flowDefinition", "");
					
					activeMap.put(flowFileName, activeVersion);
				}
			}
			
		}
		return activeMap;
	}

	/**
	 * utility method to populate the flow set and map.
	 * 
	 * @param flowFloder  the file of flow folder
	 * @param flowSet <flow file names>
	 * @param flowMap <flow name, set of flow version number>
	 */
	public void setFlows(File flowFloder, Set<String> flowSet, Map<String, Set<String>> flowMap) {
		for(File file : flowFloder.listFiles()) {
			if(file.getName().endsWith(".flow")) {
				flowSet.add(file.getName());
				String[] ss = file.getName().replace(".flow", "").split("-");
				if(flowMap.get(ss[0]) == null) {
					Set<String> set = new HashSet<String>();
					set.add(ss[1]);
					flowMap.put(ss[0], set);  // <flow name, flow version number>
				}else {
					flowMap.get(ss[0]).add(ss[1]);
				}
			}
		}
	}
	
	public void cleanFlowDefinitation() {
		File sourceFlowFolder = this.sourceSrc.toPath().resolve("flows").toFile();
		File sourceFDFolder = this.sourceSrc.toPath().resolve("flowDefinitions").toFile();
		Set<String> flowNames = new HashSet<String>();
		// get all the flow names
		for(File file : sourceFlowFolder.listFiles()) {
			if(file.getName().endsWith(".flow")) {
				flowNames.add(file.getName().split("-")[0]);
			}
		}
		
		// delete the flow definitions if the corresponding flows do not exit
		for(File file : sourceFDFolder.listFiles()) {
			if(file.getName().endsWith(".flowDefinition")) {
				String fDName = file.getName().replace(".flowDefinition", "");
				if(!flowNames.contains(fDName)) {
					this.log("Flow Definition "+file.getName() + " is deleted because the corresponding flows were deleted");
					file.delete();
				}
			}
		}
	}

	public File getTargetFlowFolder() {
		return targetSrc;
	}
	public void setTargetFlowFolder(File targetFlowFolder) {
		this.targetSrc = targetFlowFolder;
	}
	public File getSourceFlowFolder() {
		return sourceSrc;
	}
	public void setSourceFlowFolder(File sourceFlowFolder) {
		this.sourceSrc = sourceFlowFolder;
	}
}
