package com.systempartners.ci.dx;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;
import java.util.TreeSet;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;


public class PackageUtil extends Task{
	private File inputFileList;
	private File outputFileList;
	
	
	@Override
	public void execute() throws BuildException {
		super.execute();
		
		try {
			generateFileList();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/***
	 * Create a file list (outputFileList) file to include all the file has been modified.
	 * @throws Exception
	 */
	public void generateFileList() throws Exception{
		try {
			BufferedReader br = new BufferedReader(new FileReader(inputFileList));
			Set<String> set = new TreeSet<String>();
			String temp = null;
			while((temp = br.readLine()) != null){
				if(temp != null){
					if(temp.startsWith("A") || temp.startsWith("M")) {
						String[] ss = temp.split("\\s");
						if(ss.length > 1) {
							temp = ss[1];
						}else {
							continue;
						}
					}
					if(temp.indexOf("/aura/") != -1){ // lightning components
						int index = temp.lastIndexOf('/');
						temp = temp.substring(0, index);
						set.add(temp+"/*");
					}else{
						if(temp.trim().endsWith("-meta.xml")){
							int index = temp.lastIndexOf("-");
							temp = temp.substring(0, index);
						}
						set.add(temp+"*");
					}
					
				}
			}
			br.close();
			
			if(set.size() == 0){
				log("no file changed");
				return;
			}
			PrintWriter pw = new PrintWriter(new FileWriter(outputFileList));
			for(String s : set){
				pw.println(s);
			}
			pw.close();
			log(this.outputFileList.getName()+" has been generated successfully. "+ set.size() + " components in total");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public File getInputFileList() {
		return inputFileList;
	}

	public void setInputFileList(File inputFileList) {
		this.inputFileList = inputFileList;
	}

	public File getOutputFileList() {
		return outputFileList;
	}

	public void setOutputFileList(File outputFileList) {
		this.outputFileList = outputFileList;
	}
}
